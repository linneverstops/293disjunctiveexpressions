package lexer;

/**
 * TungHo Lin
 * txl429
 * PA5
 * Interface Factor
 */

public interface Factor {

    ConjunctiveRepresentation conjunctiveRepresentation();

}
