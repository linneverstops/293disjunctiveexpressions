TungHo Lin
txl429
PA5

All the source codes are in the src folder.
IdentifierTest.java is a junit test file for the class Identifier and it tests the method conjunctiveRepresentation.
CompoundFactorTest.java is a junit test file for the class CompoundFactor and it tests the method conjunctiveRepresentation.
DisjunctiveExpressionTest.java is a junit test file for the class DisjunctiveExpression and it tests the method conjunctiveRepresentation.
DisjunctiveExpression class contains a main method that create a command line interface that allows the user to input a boolean expression.
